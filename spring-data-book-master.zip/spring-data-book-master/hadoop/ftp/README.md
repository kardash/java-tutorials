# Building and running

    $ cd hadoop/ftp
    $ mvn clean package appassembler:assemble
    $ sh ./target/appassembler/bin/ftp

