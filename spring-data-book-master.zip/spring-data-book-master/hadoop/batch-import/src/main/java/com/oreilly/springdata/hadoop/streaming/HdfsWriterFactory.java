package com.oreilly.springdata.hadoop.streaming;


public interface HdfsWriterFactory {

	HdfsWriter createWriter();
	
}
