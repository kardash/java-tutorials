# Building and running

    $ cd hadoop/file-polling
    $ mvn clean package appassembler:assemble
    $ sh ./target/appassembler/bin/filepolling

