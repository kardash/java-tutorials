package com.oreilly.springdata.batch.item;

public class MultiHdfsTextItemWriter {

}
