java -cp ../../../../lib/hsqldb/hsqldb.jar org.hsqldb.util.DatabaseManager
